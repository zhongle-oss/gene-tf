import numpy as np
def Jaccard(matrix):
        matrix = np.mat(matrix)

        numerator = matrix * matrix.T

        denominator = np.ones(np.shape(matrix)) * matrix.T + matrix * np.ones(np.shape(matrix.T)) - matrix * matrix.T

        return numerator / denominator

import pandas as pd
a=pd.read_csv('/home/featurize/work/Data/tf_kegg_one.csv')
c=pd.read_csv('/home/featurize/work/Data/tf_kegg.csv',header=None)
b=a.columns

print(c)
c.apply(pd.to_numeric)
print(Jaccard(c))
